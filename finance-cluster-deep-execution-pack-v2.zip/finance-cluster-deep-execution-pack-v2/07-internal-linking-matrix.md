# 07 – Internal Linking Matrix (Mandatory)

## Matrix
- Loan → Salary + Interest + Hub
- Salary → Loan + Interest + Hub
- Interest → Loan + Salary + Hub
- Hub → All tools

## Rules
- Every finance tool page MUST:
  - include “related tools” block
  - link to hub
- The hub MUST:
  - link to every finance tool
